var builtInSets = [
   {
        name: "Duskit",
        setName: "Peace of Mind",
        evs: {
            hp: 100,
            energy: 0,
            attack: 0,
            defense: 0,
            attackR: 200,
            defenseR: 0,
            speed: 200
        },
        ivs: {
            hp: 40,
            energy: 40,
            attack: 40,
            defense: 40,
            attackR: 40,
            defenseR: 40,
            speed: 40
        },
        moves: {
            move1: "Spectral Burst",
            move2: "Brainwash",
            move3: "Peace Of Mind",
            move4: "Final Ruse"
        },
        posNature: "nimble",
        negNature: "none",
        ability: "None",
        item: "Power Cuffs",
        level: 50
    }
];
